﻿using log4net;
using RenewalApp.Infrastructure.Interfaces
    ;

namespace RenewalApp.Infrastructure.Implimentation
{
    public class Logger : ILogger
    {
        /// <summary>
        /// 
        /// </summary>
        private readonly ILog logger;

        /// <summary>
        /// Constructor initialize Objects.
        /// </summary>
        /// <param name="logger"></param>
        public Logger()
        {
            logger = LogManager.GetLogger("Log4Net");
        }

        public void Debug(object message)
        {
            logger.Debug(message);
        }


        public void Debug(object message, System.Exception exception)
        {
            logger.Debug(message, exception);
        }
        public void Info(object message)
        {
            logger.Info(message);
        }
        public void Info(object message, System.Exception exception)
        {
            logger.Info(message, exception);
        }
        public void Warn(object message)
        {
            logger.Warn(message);
        }
        public void Warn(object message, System.Exception exception)
        {
            logger.Warn(message, exception);
        }
        public void Error(object message)
        {
            logger.Error(message);
        }
        public void Error(object message, System.Exception exception)
        {
            logger.Error(message, exception);
        }
        public void Fatal(object message)
        {
            logger.Fatal(message);
        }
        public void Fatal(object message, System.Exception exception)
        {
            logger.Fatal(message, exception);
        }
    }
}
