﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RenwalApp.Business
{
    /// <summary>
    /// Helper class
    /// </summary>
    public static class Helper
    {

        public static void RenewalFormBody()
        {
            string currentDate = DateTime.Now.ToString("dd/MM/yyyy");

            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(currentDate);
            strBuilder.AppendLine();
            strBuilder.AppendLine("FAO:" + "Customer title");
            strBuilder.AppendLine("RE: Your Renewal");
            strBuilder.AppendLine();
            strBuilder.AppendLine("Dear customer’s Title followed by Surname");
            strBuilder.AppendLine();
            strBuilder.AppendLine("We hereby invite you to renew your Insurance Policy, subject to the following terms");
            strBuilder.AppendLine("Your chosen insurance product is Product Name.");
            strBuilder.AppendLine("YourThe amount payable to you in the event of a valid claim will be £Payout Amount.");
            strBuilder.AppendLine("Your annual premium will be £Annual Premium.");
            strBuilder.AppendLine("If you choose to pay by Direct Debit, we will add a credit charge of £Credit Charge, bringing the total to £Annual Premium plus Credit Charge.");
            strBuilder.Append("This is payable by an initial payment of £Initial Monthly Payment Amount, followed by 11 payments of £Other Monthly Payments Amount each.");
            strBuilder.AppendLine();
            strBuilder.AppendLine();
            strBuilder.AppendLine("Please get in touch with us to arrange your renewal by visiting https://www.regallutoncodingtest.co.uk/renew or calling us on 01625 123456");
            strBuilder.AppendLine();
            strBuilder.AppendLine("Kind Regards");
            strBuilder.AppendLine("Regal Luton");
            File.WriteAllText(@"C:\Temp\renewal.txt", strBuilder.ToString());

        }
    }
}
