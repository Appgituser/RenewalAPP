﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using RenewalApp.Core.Models;
using RenewalApp.Infrastructure.Interfaces;
using RenwalApp.Service.Implimentation;
namespace RenewalApp.Service.Tests
{
    [TestClass]
    public class CustomerServiceTests
    {
         
        [TestMethod]
        public void ValidateInputFileNotExisted_Test()
        {
            var ILogger = new Mock<ILogger>();
            CustomerService customerService = new CustomerService(ILogger.Object);
            File.Delete(@"C:\TEMP\Customer.csv");
            var result=customerService.GenerateRenewalForm();
            Assert.AreEqual(@"Please create customer.csv file in c:\temp\ locaiton", result);
        }
        [TestMethod]
        public void RecordsNotFoundInputFile_Test()
        {
            var ILogger = new Mock<ILogger>();
            CustomerService customerService = new CustomerService(ILogger.Object);
            List<CustomerModel> customers = new List<CustomerModel>();
            File.Delete(@"C:\TEMP\Customer.csv");

            if (!File.Exists(@"C:\TEMP\Customer.csv"))
            {
                var stream=File.Create(@"C:\TEMP\Customer.csv");
                stream.Close();
                File.WriteAllText(@"C:\TEMP\Customer.csv", String.Empty);


            }
            var result = customerService.GenerateRenewalForm();

            Assert.AreEqual(@"Records are not avilable in c:\\temp\\customer.csv input file.Please enter valid records", result);
        }
    }
}
