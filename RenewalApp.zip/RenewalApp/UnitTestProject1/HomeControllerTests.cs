﻿using System;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using RenewalApp.Controllers;
using RenwalApp.Service.Interfaces;

namespace UnitTestProject1
{
    [TestClass]
    public class HomeControllerTests
    {
        [TestMethod]
        public void CustormerRenewalForm_Test()
        {
            var customerService = new Mock<ICustomerService>();
            customerService.Setup(x => x.GenerateRenewalForm()).Returns("Successfully created renewalforms");
            var controller = new HomeController(customerService.Object);
            var result = controller.GenerateRenewalForm() as ViewResult;
            Assert.AreEqual("index", result.ViewName);

        }

        [TestMethod]
        public void CustormerRenewalForm_Test_Success()
        {
            var customerService = new Mock<ICustomerService>();
            customerService.Setup(x => x.GenerateRenewalForm()).Returns("Successfully created renewalforms");
            var controller = new HomeController(customerService.Object);
            var result = controller.GenerateRenewalForm();
            Assert.AreEqual("Successfully created renewalforms", result);

        }
    }
}
