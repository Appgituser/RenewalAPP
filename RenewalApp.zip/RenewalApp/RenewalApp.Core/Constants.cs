﻿namespace RenewalApp.Core
{
    public static class Constants
    {
        public const string CUSTOMER = "Customer ";
        public const string EXIST = " already existed";
        public const string SUCCESSMESSAGE = "Successfully Submitted form.";
        public const string DOWNLODEDMSG = "Generated Renewal form please find the c:\\temp\\output .";
        public const string FILEMESG = "Please create customer.csv input file in the location c:\\temp\\ .";

    }
}
