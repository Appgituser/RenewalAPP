﻿using System.Configuration;

namespace RenewalApp.Core
{
    /// <summary>
    /// Define all constants.
    /// </summary>
    public static class Constants
    {
        public static string DATE = ConfigurationManager.AppSettings["CURRENTDATE"].ToString();
        public static string TITLE = ConfigurationManager.AppSettings["TITLE"].ToString();
        public static string SURNAME = ConfigurationManager.AppSettings["SURNAME"].ToString();
        public static string FIRSTNAME = ConfigurationManager.AppSettings["FIRSTNAME"].ToString();
        public static string PRODUCTNAME = ConfigurationManager.AppSettings["PRODUCTNAME"].ToString();
        public static string PAYMENTAMOUNT = ConfigurationManager.AppSettings["PAYMENTAMOUNT"].ToString();
        public static string ANNUALAMOUNT = ConfigurationManager.AppSettings["ANNUALAMOUNT"].ToString();
        public static string CREDITCHANRGES = ConfigurationManager.AppSettings["CREDITCHANRGES"].ToString();
        public static string TOTALAMOUNT = ConfigurationManager.AppSettings["TOTALAMOUNT"].ToString();
        public static string INITIALMONTHLYPAYMENTAMOUNT = ConfigurationManager.AppSettings["INITIALMONTHLYPAYMENTAMOUNT"].ToString();

        public static string OTHERPAYMENTAMOUNT = ConfigurationManager.AppSettings["OTHERPAYMENTAMOUNT"].ToString();
        public static string FILENOTFOUNDMESSAGE = ConfigurationManager.AppSettings["FILENOTFOUNDMESSGE"].ToString();
        public static string SUCCESSMESSAGE = ConfigurationManager.AppSettings["SUCCESSMESSAGE"].ToString();
        public static string RENEWALFORMTEMPLATEPATH = ConfigurationManager.AppSettings["RENEWALFORMTEMPLATEPATH"].ToString();
        public static string RECORDSNOTFOUND = ConfigurationManager.AppSettings["RECORSNOUTFOUNDMESSAGE"].ToString();
        public static string FILENAMENOTEXISTEDMESSGE = ConfigurationManager.AppSettings["CUSTOMERNAMEEXISTEDMESSAGE"].ToString();
        public static string PAYMENTAMOUNTVALIDATIONMESSAGE = ConfigurationManager.AppSettings["PAYMENTAMOUNTVALIDATIONMESSAGE"].ToString();
        public static string ANNUALPREMIUMTVALIDATIONMESSAGE = ConfigurationManager.AppSettings["ANNUALPREMIUMVALIDATIONMESSAGE"].ToString();
        public static string CUSTOMERNAMEDUPLICATEMESAGE = ConfigurationManager.AppSettings["CUSTOMERNAMEDUPLICATEMESAGE"].ToString();
        public static string CURRENCYEMPTYCHEK = ConfigurationManager.AppSettings["CURRENCYEMPTYCHEK"].ToString();
        public static string NAMESEMPTYCHECK = ConfigurationManager.AppSettings["NAMESEMPTYCHECK"].ToString();

    }
}
