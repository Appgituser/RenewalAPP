﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RenewalApp.Core.Models
{
    /// <summary>
    /// Customer model contains renewal data
    /// </summary>
    public class CustomerModel
    {

        private double creditChange;
        private double totalPremium;
        private double otherPayment;
        private double initialMothlypayment;
        
        public double avgMonthlyAmount { get; set; }

        public string ID { get; set; } 
        
        public string Title { get; set; }


        public string FirstName { get; set; }
        public string SurName { get; set; }


        public string ProductName { get; set; }

        public double PayoutAmount { get; set; }

        public double AnnualPremium { get; set; }



        public double CreditCharge
        {
            get
            {
                return creditChange = Math.Round((double)(5 * (AnnualPremium / 100)),2);
            }
            set
            {
                this.creditChange = value;
            }

        }

        public double TotalPremium
        {
            get { return totalPremium = Math.Round((double)AnnualPremium,2) + CreditCharge; }
            set { this.totalPremium = value; }
        }

        public double AvgMonthlyPremium
        {
            get { return (avgMonthlyAmount = TotalPremium / 12); }
            set { this.avgMonthlyAmount = Math.Round((double)value,2); }
        }


        public double OtherPaymentAmount
        {
            get { return otherPayment = Math.Round((double)AvgMonthlyPremium, 2); }
            set { this.otherPayment = value; }
        }
        public double InitialMonthlyPaymentAmount
        {
            get { return initialMothlypayment = Math.Round((double)(TotalPremium - OtherPaymentAmount * 11), 2); }
            set { this.initialMothlypayment = value; }
        }

      
    }
}
