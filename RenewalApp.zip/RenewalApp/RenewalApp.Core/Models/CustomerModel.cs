﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RenewalApp.Core.Models
{
    /// <summary>
    /// Customer model contains renewal data
    /// </summary>
    public class CustomerModel
    {
        public string ID { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string SurName { get; set; }
        public string ProductName { get; set; }
        public double PayoutAmount { get; set; }
        public double AnnualPremium { get; set; }
        public double CreditCharge
        {
            get { return Math.Round((5 * (AnnualPremium / 100)), 2); }
            set { }
        }
        public double TotalPremium
        {
            get { return Math.Round(AnnualPremium, 2) + CreditCharge; }
            set { }
        }

        public double AvgMonthlyPremium
        {
            get { return Math.Round(TotalPremium / 12, 2); }
            set { }
        }

        public double OtherPaymentAmount
        {
            get { return Math.Round(AvgMonthlyPremium, 2); }
            set { }
        }
        public double InitialMonthlyPaymentAmount
        {
            get { return Math.Round((TotalPremium - OtherPaymentAmount * 11), 2); }
            set { }
        }
    }
}
