﻿using RenewalApp.Core;
using RenewalApp.Core.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace RenwalApp.Core
{

    /// <summary>
    /// Helper class
    /// </summary>
    public static class Helper
    {

        /// <summary>
        /// REMEWAL FORM BODY FORMAT
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static string RenewalFormBody(CustomerModel model, string fileData)
        {

            string currentDate = DateTime.Now.ToString("dd/MM/yyyy");
            fileData = fileData.Replace("<" + Constants.DATE + ">", currentDate);
            fileData = fileData.Replace("<" + Constants.TITLE + ">", model.Title);
            fileData = fileData.Replace("<" + Constants.FIRSTNAME + ">", model.FirstName);
            fileData = fileData.Replace("<" + Constants.SURNAME + ">", model.SurName);
            fileData = fileData.Replace("<" + Constants.PRODUCTNAME + ">", model.ProductName);
            fileData = fileData.Replace("<" + Constants.PAYMENTAMOUNT + ">", "£" + model.PayoutAmount.ToString());
            fileData = fileData.Replace("<" + Constants.ANNUALAMOUNT + ">", "£" + model.AnnualPremium.ToString());
            fileData = fileData.Replace("<" + Constants.CREDITCHANRGES + ">", "£" + model.CreditCharge.ToString());
            fileData = fileData.Replace("<" + Constants.TOTALAMOUNT + ">", "£" + model.TotalPremium.ToString());
            fileData = fileData.Replace("<" + Constants.INITIALMONTHLYPAYMENTAMOUNT + ">", "£" + model.InitialMonthlyPaymentAmount.ToString());
            fileData = fileData.Replace("<" + Constants.OTHERPAYMENTAMOUNT + ">", "£" + model.OtherPaymentAmount.ToString());
            return fileData;
        }


        /// <summary>
        /// READ CSV FILE
        /// </summary>
        /// <param name="csvLine"></param>
        /// <returns></returns>
        public static CustomerModel CsvConvertion(string csvLine)
        {
            string[] values = csvLine.Split(',');
            var payment = values[6];
            CustomerModel model = new CustomerModel();
            model.ID = (!string.IsNullOrEmpty(values[0])) ? Convert.ToString(values[0]) : string.Empty;
            model.Title = (!string.IsNullOrEmpty(values[1])) ? Convert.ToString(values[1]) : string.Empty;
            model.FirstName = (!string.IsNullOrEmpty(values[2])) ? Convert.ToString(values[2]) : string.Empty;
            model.SurName = (!string.IsNullOrEmpty(values[3])) ? Convert.ToString(values[3]) : string.Empty;
            model.ProductName = (!string.IsNullOrEmpty(values[4])) ? Convert.ToString(values[4]) : string.Empty;
            model.PayoutAmount = values[5] != string.Empty ? Convert.ToDouble(values[5]) : 00.00;
            model.AnnualPremium = values[6] != string.Empty ? Convert.ToDouble(values[6]) : 00.00;

            return model;
        }




        /// <summary>
        /// Validate file name and check already existed.
        /// </summary>
        /// <returns></returns>
        public static bool ValidateRenewalFileName(string root, string fileName)
        {
            return new DirectoryInfo(root).GetFiles().Select(o => Path.GetFileNameWithoutExtension(o.Name.ToLower())).ToList().Contains(fileName.ToLower());
        }

        /// <summary>
        /// Validate Credit  charge and Payment amount currency input data.
        /// </summary>
        /// <param name="inputPrice"></param>
        /// <returns></returns>
        public static bool ValidateCurrency(string inputPrice)
        {
            var regex = new Regex(@"^[0-9]{0,6}(\.[0-9]{1,2})?$");
            return regex.IsMatch(inputPrice) ? true : false;

        }


        /// <summary>
        /// Validate file name from customer.csv file.
        /// </summary>
        /// <returns></returns>
        public static List<string> ValidateCsvFile(string filePath)
        {
            List<string> duplicateCustomers = new List<string>();

            if (File.Exists(filePath) && (new FileInfo(filePath).Length > 0))
            {
                var csvList = File.ReadLines(filePath).ToList().Select(line => line.Split(','));
                var firstNames = csvList.Select(items => items[2]).ToList().GroupBy(x => x).Where(g => g.Count() > 1).Select(y => y.Key.ToString()).ToList();
                var Ids = csvList.Select(items => items[0]).ToList().GroupBy(x => x).Where(g => g.Count() > 1).Select(y => y.Key.ToString()).ToList();
                var surNames = csvList.Select(items => items[3]).GroupBy(x => x).Where(g => g.Count() > 1).Select(y => y.Key.ToString()).ToList();

                duplicateCustomers = firstNames.Count > 0 ? firstNames : Ids.Count > 0 ?
                    Ids : surNames.Count > 0 ? surNames : new List<string>();



            }
            return duplicateCustomers;
        }
    }
}

