﻿using RenewalApp.Core.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace RenwalApp.Core
{
    /// <summary>
    /// Helper class
    /// </summary>
    public static class Helper
    {
        /// <summary>
        /// REMEWAL FORM BODY FORMAT
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static StringBuilder RenewalFormBody(CustomerModel model)
        {
            string currentDate = DateTime.Now.ToString("dd/MM/yyyy");

            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine(currentDate);
            strBuilder.AppendLine();
            strBuilder.AppendLine("FAO:" + model.Title + " " + model.SurName + " " + model.FirstName);
            strBuilder.AppendLine("RE: Your Renewal");
            strBuilder.AppendLine();
            strBuilder.AppendLine("Dear " + model.Title + " " + model.SurName);
            strBuilder.AppendLine();
            strBuilder.AppendLine("We hereby invite you to renew your Insurance Policy, subject to the following terms");
            strBuilder.AppendLine("Your chosen insurance product is " + model.ProductName);
            strBuilder.AppendLine("Your The amount payable to you in the event of a valid claim will be £" + model.PayoutAmount);
            strBuilder.AppendLine("Your annual premium will be £" + model.AnnualPremium);
            strBuilder.AppendLine("If you choose to pay by Direct Debit, we will add a credit charge of £" + model.CreditCharge + ", bringing the total to £" + model.TotalPremium);
            strBuilder.Append("This is payable by an initial payment of £" + model.InitialMonthlyPaymentAmount + ", followed by 11 payments of £" + model.OtherPaymentAmount + " Other Monthly Payments Amount each.");
            strBuilder.AppendLine();
            strBuilder.AppendLine();
            strBuilder.AppendLine("Please get in touch with us to arrange your renewal by visiting https://www.regallutoncodingtest.co.uk/renew or calling us on 01625 123456");
            strBuilder.AppendLine();
            strBuilder.AppendLine("Kind Regards");
            strBuilder.AppendLine("Regal Luton");

            return strBuilder;


        }


        /// <summary>
        /// READ CSV FILE
        /// </summary>
        /// <param name="csvLine"></param>
        /// <returns></returns>
        public static CustomerModel FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(',');
            CustomerModel model = new CustomerModel();
            model.ID = Convert.ToString(values[0]);
            model.Title = Convert.ToString(values[1]);
            model.FirstName = Convert.ToString(values[2]);
            model.SurName = Convert.ToString(values[3]);
            model.ProductName = Convert.ToString(values[4]);
            model.PayoutAmount = Convert.ToDouble(values[5]);
            model.AnnualPremium = Convert.ToDouble(values[6]);

            return model;
        }


        /// <summary>
        /// Validate file name from customer.csv file.
        /// </summary>
        /// <returns></returns>
        public static bool ValidateFile(string filePath, string name)
        {
            if (File.Exists(filePath) && (new FileInfo(filePath).Length > 0))
            {
                return File.ReadLines(filePath).ToList().Select(line => line.Split(',')).ToList().
                        Select(items => items[2]).ToList().Any(x => x.ToLower() == name.ToLower());
            }
            return false; ;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static bool ValidateOutFile(string root, string fileName)
        {
            var fileList = new DirectoryInfo(root).GetFiles().Select(o => Path.GetFileNameWithoutExtension(o.Name)).ToList();
            return fileList.Select(x => x.Split('_')[0].ToLower()).ToList().Contains(fileName.ToLower());

        }


































    }
}
