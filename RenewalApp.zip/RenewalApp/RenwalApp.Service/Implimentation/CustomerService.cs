﻿using RenewalApp.Core.Models;
using RenwalApp.Core;
using RenwalApp.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;

namespace RenwalApp.Service.Implimentation
{
    /// <summary>
    /// Customer interface create application form.
    /// </summary>
    public class CustomerService : ICustomerService
    {
        #region valirables
        string inputFile = ConfigurationManager.AppSettings["INPUT"].ToString();
        string outputFilePath = ConfigurationManager.AppSettings["OUTPUTFILEPATH"].ToString();
        #endregion

        #region Public Methods
        /// <summary>
        /// create and renewal form in the file system.
        /// </summary>
        /// <param name="customerModel"></param>
        public bool GenerateRenewalForm()
        {
            try
            {                
                if (!File.Exists(inputFile))
                {
                    return false;
                }
                else
                {
                    //read csv file
                    List<CustomerModel> customers = File.ReadAllLines(inputFile) != null ? File.ReadAllLines(inputFile)
                                               .Skip(1)
                                               .Select(v => v != null ? Helper.FromCsv(v) : null)
                                               .ToList() : null;
                    if (customers == null || customers.Count == 0)
                    {
                        return false;
                    }
                    //Create directory if not exis
                    if (!Directory.Exists(outputFilePath))
                    {
                        Directory.CreateDirectory(outputFilePath);
                    }
                    //Loop each customer list and create renewal form in output file path.
                    foreach (var item in customers)
                    {
                        List<string> fileList = new List<string>();
                        var result = Helper.RenewalFormBody(item);
                        //check file already exist and create directory
                        
                        if (!Helper.ValidateOutFile(outputFilePath, item.FirstName)){
                            //Write file into file system
                            File.WriteAllText(outputFilePath + item.FirstName + "_" + item.ID + ".txt", result.ToString());
                        }
                    }
                }
                return true;
            }

            catch (System.Exception ex)
            {

                throw new System.Exception(ex.InnerException.ToString());
            }

        }

        /// <summary>
        /// create csv file with givn model input
        /// </summary>
        /// <param name="customerModel"></param>
        /// <returns></returns>
        public bool GenerateCsvFile(CustomerModel customerModel)
        {
            try
            {
                string header = ConfigurationManager.AppSettings["HEADER"].ToString() + Environment.NewLine;
                string file = ConfigurationManager.AppSettings["FILEPATH"].ToString();

                if (!Directory.Exists(file))
                {
                    Directory.CreateDirectory(file);
                    var fileStream = File.Create(file+"customer.csv");
                    fileStream.Close();
                }
                if (!Helper.ValidateFile(inputFile, customerModel.FirstName))
                {
                    string data = customerModel.ID + "," + customerModel.Title + ',' + customerModel.FirstName + "," + customerModel.SurName + ","
                        + customerModel.ProductName + "," + customerModel.PayoutAmount + "," + customerModel.AnnualPremium + Environment.NewLine;
                    if (!File.Exists(inputFile) || (new FileInfo(inputFile).Length == 0))
                    {
                        File.WriteAllText(inputFile, header);
                    }
                    File.AppendAllText(inputFile, data);
                    return true;
                }

            }
            catch (Exception ex)
            {

                new Exception(ex.InnerException.ToString());
            }
            return false;

        }

        #endregion
    }
}
