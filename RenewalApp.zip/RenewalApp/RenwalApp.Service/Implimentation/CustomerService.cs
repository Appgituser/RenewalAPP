﻿using RenewalApp.Core;
using RenewalApp.Core.Models;
using RenewalApp.Infrastructure.Interfaces;
using RenwalApp.Core;
using RenwalApp.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace RenwalApp.Service.Implimentation
{
    /// <summary>
    /// Customer interface create application form.
    /// </summary>
    public class CustomerService : ICustomerService
    {
        #region Global valirables
        string inputFile = ConfigurationManager.AppSettings["INPUT"].ToString();
        string outputFilePath = ConfigurationManager.AppSettings["OUTPUTFILEPATH"].ToString();
        private readonly ILogger logger;
        #endregion

        #region Constructor
        /// <summary>
        /// Cunstructor for initialization
        /// </summary>
        public CustomerService(ILogger logger)
        {
            this.logger = logger;
        }

        #endregion

        #region Public Methods
        /// <summary>
        /// Read records from customer.csv file and generate renewal forms for each customer in csv file.
        /// </summary>
        /// <returns></returns>
        public string GenerateRenewalForm()
        {
            string message = string.Empty;
            try
            {
                //check customer.csv file existed in given location.
                if (!File.Exists(inputFile))
                {
                    logger.Error(Constants.FILENOTFOUNDMESSAGE);
                    return Constants.FILENOTFOUNDMESSAGE;

                }

                //read customer.csv file and convert into list of customer model object.
                List<CustomerModel> customers = File.ReadAllLines(inputFile) != null ? File.ReadAllLines(inputFile)
                                           .Skip(1)
                                           .Select(v => v != null ? Helper.FromCsv(v) : null)
                                           .ToList() : null;
                //Validate filename and currency format for each given customer.csv input file return validation message.
                message = ValidateInputFile(customers);
                if (message == string.Empty)
                {
                    //Create directory if not exis
                    if (!Directory.Exists(outputFilePath))
                    {
                        Directory.CreateDirectory(outputFilePath);
                    }
                    //create multiple threds and create renewal forms in output location.
                    Parallel.ForEach(customers, (item) =>
                    {

                        //Read renewal form template from Project ..\RenewalApp\RenewalApp\files\ directory.
                        string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "files", Constants.RENEWALFORMTEMPLATEPATH);

                        string fileText = System.IO.File.ReadAllText(path);
                        //Geneate Renewal form from given customer.csv input file.
                        string formData = Helper.RenewalFormBody(item, fileText);
                        File.WriteAllText(outputFilePath + item.FirstName + "_" + item.ID + ".txt", formData);
                        message = Constants.SUCCESSMESSAGE;

                    });
                    return message;
                }
                return message;

            }

            catch (System.Exception ex)
            {
                throw new System.Exception(ex.InnerException.ToString());
            }
        }

        #endregion

        #region PrivateMethods



        /// <summary>
        /// Validate records,file name and currency existed in customer.csv file.
        /// </summary>
        /// <param name="customers"></param>
        /// <returns></returns>
        private string ValidateInputFile(List<CustomerModel> customers)
        {

            //check records existed in customer.csv input file.
            if (customers == null || customers.Count == 0)
            {
                logger.Error(Constants.RECORDSNOTFOUND);
                return Constants.RECORDSNOTFOUND;

            }
            var results = Helper.ValidateCsvFile(inputFile);
            if (results != null && results.Count>0)
            {
                string message = string.Join(",", results);
                logger.Error(string.Format(Constants.CUSTOMERNAMEDUPLICATEMESAGE, message));
                return string.Format(Constants.CUSTOMERNAMEDUPLICATEMESAGE, message);
            }

            //Create directory if not exis
            if (Directory.Exists(outputFilePath))
            {
                foreach (var item in customers)
                {



                    if (Helper.ValidateOutFile(outputFilePath, item.FirstName))
                    {
                        logger.Error(string.Format(Constants.FILENAMENOTEXISTEDMESSGE, item.FirstName));
                        return string.Format(Constants.FILENAMENOTEXISTEDMESSGE, item.FirstName);
                    }
                    //Validate  paymentamount and annualpremium input data.
                    if (!Helper.ValidateCurrency(item.PayoutAmount.ToString()))
                    {
                        logger.Error(string.Format(Constants.PAYMENTAMOUNTVALIDATIONMESSAGE, item.ProductName, item.FirstName));
                        return string.Format(Constants.PAYMENTAMOUNTVALIDATIONMESSAGE, item.ProductName, item.FirstName);

                    }
                    if (!Helper.ValidateCurrency(item.AnnualPremium.ToString()))
                    {
                        logger.Error(string.Format(Constants.ANNUALPREMIUMTVALIDATIONMESSAGE, item.ProductName, item.FirstName));
                        return string.Format(Constants.ANNUALPREMIUMTVALIDATIONMESSAGE, item.ProductName, item.FirstName);

                    }
                }
            }

            return string.Empty;
        }

        #endregion
    }
}
