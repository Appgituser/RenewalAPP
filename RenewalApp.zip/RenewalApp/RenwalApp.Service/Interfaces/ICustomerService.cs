﻿

/// <summary>
/// 
/// </summary>
namespace RenwalApp.Service.Interfaces
{
    /// <summary>
    /// Customerservice interface
    /// </summary>
    public interface ICustomerService
    {
         string GenerateRenewalForm();
    }
}
