﻿using RenewalApp.Core.Models;

/// <summary>
/// 
/// </summary>
namespace RenwalApp.Service.Interfaces
{
    /// <summary>
    /// Customerservice interface
    /// </summary>
    public interface ICustomerService
    {
        bool GenerateRenewalForm();
        bool GenerateCsvFile(CustomerModel customerModel);
    }
}
