﻿using RenewalApp.Core;
using RenewalApp.Models;
using RenwalApp.Mappers;
using RenwalApp.Service.Implimentation;
using RenwalApp.Service.Interfaces;
using System;
using System.Web.Mvc;

namespace RenewalApp.Controllers
{
    /// <summary>
    /// Home controller
    /// </summary>
    public class HomeController : Controller
    {
        #region variables
        private readonly ICustomerService customer;
        #endregion

        #region constructor
        public HomeController()
        {
            customer = new CustomerService();
        }
        #endregion

        #region ActionMethods
        /// <summary>
        /// Action method generate renewal form
        /// </summary>
        /// <returns></returns>
        public ActionResult GenerateRenewalForm()
        {
            try
            {
                if (customer.GenerateRenewalForm())
                {
                    ViewBag.DownlodMsg = Constants.DOWNLODEDMSG;
                }
                else
                {
                    ViewBag.DownlodMsg = Constants.FILEMESG;
                }
                return View("About");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.InnerException.ToString());
            }
        }

        /// <summary>
        /// Actionmethod generate customer.csv input file
        /// </summary>
        /// <param name="customerModel"></param>
        /// <returns></returns>
        public ActionResult GenerateCsv(CustomerViewModel customerModel)
        {
            try
            {
                string message = string.Empty;
                //Map view model to view
                var customerData = CustomerMapper.MapCustomerData(customerModel);
                //Generate customer.csv input file
                if (customer.GenerateCsvFile(customerData))
                {
                    ViewBag.Msg = Constants.SUCCESSMESSAGE;
                }
                else
                {
                    ViewBag.Msg = Constants.CUSTOMER + customerModel.FirstName + Constants.EXIST;

                }
                ModelState.Clear();
                return View("index");
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }


        public ActionResult Index()
        {


            return View();
        }

        #endregion

    }
}