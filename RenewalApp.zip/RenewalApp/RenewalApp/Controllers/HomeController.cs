﻿using RenewalApp.Infrastructure.Interfaces;
using RenwalApp.Service.Interfaces;
using System;
using System.Web.Mvc;

namespace RenewalApp.Controllers
{
    /// <summary>
    /// Home controller
    /// </summary>
    public class HomeController : Controller
    {
        #region variables
        private readonly ICustomerService customer;
        #endregion

        #region constructor
        public HomeController(ICustomerService customer)
        {
            this.customer = customer;
        }
        #endregion

        #region ActionMethods
        /// <summary>
        /// Action method generate renewal form
        /// </summary>
        /// <returns></returns>
        public ActionResult GenerateRenewalForm()
        {
            try
            {
                var result = customer.GenerateRenewalForm();
                ViewBag.Message = result;
                return View("index");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.InnerException.ToString());
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            try
            {
            
                return View();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

        }

        #endregion

    }
}