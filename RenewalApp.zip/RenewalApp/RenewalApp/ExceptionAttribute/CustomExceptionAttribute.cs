﻿using log4net;
using System.Web.Mvc;

namespace RenewalApp.ExceptionAttribute
{
    /// <summary>
    /// Custom attribute handle unhandled exception.
    /// </summary>
    public class CustomExceptionAttribute : HandleErrorAttribute
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnException(ExceptionContext filterContext)
        {
            var exception = filterContext.Exception;

            ILog log = LogManager.GetLogger("Log4Net");
            log.Error("Error", exception);
        }
    }
}