﻿using System.ComponentModel.DataAnnotations;

namespace RenewalApp.Models
{
    /// <summary>
    /// The customer input file.
    /// </summary>
    public class CustomerViewModel
    {
   
        public string ID { get; set; }

        [Required(ErrorMessage = "Enter Title")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Enter SurName")]
        public string SurName { get; set; }
        [Required(ErrorMessage = "Enter First Name")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Enter Product Name")]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "Enter Payout Amount")]
        [RegularExpression(@"^[0-9]{0,6}(\.[0-9]{1,2})?$", ErrorMessage = "Payout Amount should be 2 decimal places.")]
        public double PayoutAmount { get; set; }

        [Required(ErrorMessage = "Enter Annual Premium")]
        [RegularExpression(@"^[0-9]{0,6}(\.[0-9]{1,2})?$", ErrorMessage = "Annual Premium should be 2 decimal places.")]
        public double AnnualPremium { get; set; }

        public double CreditCharge { get; set; }
      
        public double TotalPremium { get; set; }

        public double AvgMonthlyPremium { get; set; }

        public double InitialMonthlyPaymentAmount { get; set; }

        public double OtherPaymentAmount { get; set; }

    }
}