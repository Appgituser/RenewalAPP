﻿using RenewalApp.ExceptionAttribute;
using System.Web;
using System.Web.Mvc;

namespace RenewalApp
{
    public class FilterConfig
    {
        /// <summary>
        /// Register custom attribute in global level.
        /// </summary>
        /// <param name="filters"></param>
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new CustomExceptionAttribute());
        }
    }
}
