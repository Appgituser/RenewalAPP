using RenewalApp.Infrastructure.Implimentation;
using RenewalApp.Infrastructure.Interfaces;
using RenwalApp.Service.Implimentation;
using RenwalApp.Service.Interfaces;
using System.Web.Mvc;
using Unity;
using Unity.Mvc5;

namespace RenewalApp
{
    /// <summary>
    /// Loads all dependencies.
    /// </summary>
    public static class UnityConfig
    {
        /// <summary>
        /// Register services in unity container.
        /// </summary>
        public static void RegisterComponents()
        {
			var container = new UnityContainer();
            container.RegisterType<ICustomerService, CustomerService>();
            container.RegisterType<ILogger, Logger>();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}