﻿using RenewalApp.Core.Models;
using RenewalApp.Models;
using System;

namespace RenwalApp.Mappers
{
    /// <summary>
    /// mapper class map view model to  model class.
    /// </summary>
    public static class CustomerMapper
    {
        /// <summary>
        /// Return customermodel.
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public static CustomerModel MapCustomerData(CustomerViewModel viewModel)
        {

            return new CustomerModel()
            {
                ID = string.Format("{0:d9}", (DateTime.Now.Ticks / 10) % 1000000000).Substring(0, 4),
                Title = viewModel.Title,
                FirstName = viewModel.FirstName,
                SurName = viewModel.SurName,
                ProductName=viewModel.ProductName,
                AnnualPremium=viewModel.AnnualPremium,
                PayoutAmount = viewModel.PayoutAmount,
                CreditCharge = viewModel.CreditCharge,
                TotalPremium = viewModel.TotalPremium,
                avgMonthlyAmount = viewModel.AvgMonthlyPremium,
                InitialMonthlyPaymentAmount = viewModel.InitialMonthlyPaymentAmount,
                OtherPaymentAmount = viewModel.OtherPaymentAmount

            };
        }
    }
}
